import os
from cls_Knn import *
import numpy as np
from PIL import Image
import shutil


def copy_files_model(cluster_n, p2f, dir_n, n_files):

    d = Files2model()
    d.set_cluster_names(cluster_n)
    d.set_path2f(p2f)


    cur_dir = os.curdir
    os.mkdir(cur_dir+'/'+dir_n)
    mod_list = []
    ncat = 3000
    ndog = 3000

    for i in d.file_list:

        if 'dog' in i and ndog <= n_files:
            mod_list.append(i)
            ndog += 1
        if 'cat' in i and ncat <= n_files:
            mod_list.append(i)
            ncat +=1
        if ndog > n_files and ncat > n_files:
            break

    for i in mod_list:
        shutil.copy(i, cur_dir+'/'+dir_n+'/')

    return mod_list

def check_copied_file_size(mod_list):

    bNh = []
    XbNh = []

    for i in mod_list:

        img = Image.open(i)
        b = img.size[0]
        h = img.size[1]

        if b > 200 and h > 200:
            bNh.append(i)   
        else:
            XbNh.append(i)
    
    return bNh, XbNh

def count_XbNh(cluster_n, XbNh):

    l_XbNh = []
    for i in cluster_n:
        for j in XbNh:
            if i in j:
                l_XbNh.append(i)
        print(f'{i}: {l_XbNh.count(i)}')


cluster_n = ['dog','cat']
#p2f = ['C:\\tmp\\repo\\data\\train\\cats', 'C:\\tmp\\repo\\data\\train\\dogs']
p2f = ['C:\\Users\\MSI GAMING\\KNN_OOP_GUI\\test_500']
#dir_n = 'test_500'
#n_files = 3500
#mod_list = copy_files_model(cluster_n, p2f, dir_n, n_files)
#bNh, XbNh = check_copied_file_size(mod_list)
#count_XbNh(cluster_n, XbNh)

b = 75
h = 75

def make_model(cluster_n, p2f, b, h, model_name = 'Model_Img_'):

    d = Files2model()
    d.set_path2f(p2f)
    d.set_cluster_names(cluster_n)
    d.model_file()
    model_sng_list = scale_n_grey_fnp(d.model_file_list, b, h)
    bilder = make_model_file(model_sng_list, d.model_id_list, model_name)

make_model(cluster_n, p2f, b, h, model_name = '500_Model_Img_')























