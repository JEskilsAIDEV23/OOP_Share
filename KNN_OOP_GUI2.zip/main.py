import sys
import os
from cls_Knn import *

from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import (
    QAction,
    QApplication,
    QCheckBox,
    QLabel,
    QMainWindow,
    QStatusBar,
    QToolBar,
    QVBoxLayout,
)
from MainWindow import Ui_MainWindow

class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, *args, obj=None, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.setupUi(self)
        self.menuBar()
        self.setStyleSheet("background-color: White;")
        self.k = 3
        self.action100x100.triggered.connect(lambda: self.set_model_100())
        self.action200x200.triggered.connect(lambda: self.set_model_200())
        self.action50x50.triggered.connect(lambda: self.set_model_50())
        self.actionOther.triggered.connect(lambda: self.set_model_X())
        self.actionOpen_Image.triggered.connect(lambda: self.openFileNameDialog())
        pixmap = QPixmap('start.png')
        self.label_tIMG.setPixmap(QPixmap(pixmap))
        self.label_tIMG.setAlignment(Qt.AlignCenter)
        self.label_tIMG_2.setPixmap(QPixmap(pixmap))
        self.label_tIMG_2.setAlignment(Qt.AlignCenter)
        pixmap2 = QPixmap('start_2.png')
        self.label_3.setPixmap(QPixmap(pixmap2))
        self.label_3.setAlignment(Qt.AlignCenter)        
        self.label_4.setPixmap(QPixmap(pixmap2))
        self.label_4.setAlignment(Qt.AlignCenter) 
        self.label_5.setPixmap(QPixmap(pixmap2))
        self.label_5.setAlignment(Qt.AlignCenter)
        self.label.setText('Model: ')
        self.label_2.setText('Test File: ')
        self.radioButton.k = 5
        self.radioButton.toggled.connect(self.onClicked)
        self.radioButton_2.setChecked(True)
        self.radioButton_2.k = 3
        self.radioButton_2.toggled.connect(self.onClicked)
        self.pushButton.clicked.connect(lambda: self.run_knn())
        self.radioButton_3.k = 7
        self.radioButton_3.toggled.connect(self.onClicked)

    def run_knn(self):

        print(f'K-value: {self.k}')
        print(f'Model: {self.Model}')
        print(f'Test File: {self.test_file}')
        print(f'Width: {self.b}')
        print(f'Height: {self.h}')

        knn_model = Calculate_Knn(self.test_file, self.Model, self.b, self.h, self.k)
        
        n_bilder_mod = len(knn_model.bilder)
        self.textBrowser.clear()
        self.textBrowser.append(f'Model with {n_bilder_mod} Images')
        self.knn_cs = list(set(knn_model.class_list))
        res_txt = ''
        res_lib = {}

        for i in range(len(self.knn_cs)):
            res_txt = res_txt + f'{self.knn_cs[i]}: {knn_model.class_list.count(self.knn_cs[i])}\n'
            res_lib[self.knn_cs[i]] = knn_model.class_list.count(self.knn_cs[i])
            if self.knn_cs[i] in self.test_file:
                self.testC = self.knn_cs[i]

        res_max = 0    
        for key in res_lib.keys():
            if res_lib[key] >= res_max:
                res_max = res_lib[key]
                res_c = key

        if res_c == self.testC:
            self.class_txt_res = f'TestFile Classed Correct as {res_c}'
            pixmap = QPixmap('tmp_img.png')
            self.label_tIMG.setPixmap(QPixmap(pixmap))
            self.label_tIMG.resize(pixmap.width(),pixmap.height())
            self.label_tIMG.setAlignment(Qt.AlignCenter)

        if res_c != self.testC:
            self.class_txt_res = f'TestFile Not Classed Correct'
            x_img(test_img='tmp_img.png', cross_img='cross.png')
            pixmap = QPixmap('Xtmp_img.png')
            self.label_tIMG.setPixmap(QPixmap(pixmap))
            self.label_tIMG.resize(pixmap.width(),pixmap.height())
            self.label_tIMG.setAlignment(Qt.AlignCenter)

        self.res_txt = res_txt
        print(self.res_txt)
        self.textBrowser.append(self.res_txt)
        self.textBrowser.append(self.class_txt_res)
        pixmap = QPixmap('grey_tmp_img.png')
        self.label_tIMG_2.setPixmap(QPixmap(pixmap))
        self.label_tIMG_2.resize(pixmap.width(),pixmap.height())
        self.label_tIMG_2.setAlignment(Qt.AlignCenter)

        n = 1
        for i in range(len(knn_model.file_index)):
            if n == 1:
                pixmap3 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            if n == 2:
                pixmap4 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            if n == 3:
                pixmap5 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            n +=1

        self.label_4.setPixmap(QPixmap(pixmap4))       
        self.label_5.setPixmap(QPixmap(pixmap5))
        self.label_3.setPixmap(QPixmap(pixmap3))

    def onClicked(self):
        radioButton = self.sender()
        if radioButton.isChecked():
            self.k = radioButton.k

    def set_model_50(self):
        self.label.setText('Model: 50x50')
        self.Model = 'Model_Img_(50x50).npz'
        self.b = 50
        self.h = 50

    def set_model_100(self):
        self.label.setText('Model: 100x100')
        self.Model = 'Model_Img_(100x100).npz'
        self.b = 100
        self.h = 100

    def set_model_200(self):
        self.label.setText('Model: 200x200')
        self.Model = 'Model_Img_(200x200).npz'
        self.b = 200
        self.h = 200

    def set_model_X(self):
        cur_dir = os.curdir
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName, _ = QFileDialog.getOpenFileName(self,"QFileDialog.getOpenFileName()", cur_dir+"","Model Files (*.npz)", options=options)
        if fileName:
            print(fileName)
            mN = fileName.split('/')[4]
            self.label.setText(mN)
            self.Model = fileName
            fN = fileName.split('(')
            fN = fN[1].split(')')
            fN = fN[0].split('x')
            self.b = int(fN[0])
            self.h = int(fN[1])
            print(self.b, self.h)

    def openFileNameDialog(self):
        cur_dir = os.curdir
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName, _ = QFileDialog.getOpenFileName(self,"QFileDialog.getOpenFileName()", cur_dir+"","Img Files (*.jpg)", options=options)
        if fileName:
            print(fileName)
            self.test_file = fileName
            fN = fileName.split('/')
            self.label_2.setText(fN[5])
            img = Image.open(fileName)
            b = img.size[0]
            h = img.size[1]
            if b > 300 or h > 300:
                size = (int(b*0.5), int(h*0.5))
            else:
                size = (int(b), int(h))
            img = img.resize(size)
            img.save('tmp_img.png')
            pixmap = QPixmap('tmp_img.png')
            self.label_tIMG.setPixmap(QPixmap(pixmap))
            self.label_tIMG.resize(pixmap.width(),pixmap.height())
            self.label_tIMG.setAlignment(Qt.AlignCenter)
            pixmapX = QPixmap('start.png')
            pixmap2 = QPixmap('start_2.png')
            self.label_tIMG_2.setPixmap(QPixmap(pixmapX))
            self.label_tIMG_2.setAlignment(Qt.AlignCenter)
            self.label_3.setPixmap(QPixmap(pixmap2))
            self.label_3.setAlignment(Qt.AlignCenter)        
            self.label_4.setPixmap(QPixmap(pixmap2))
            self.label_4.setAlignment(Qt.AlignCenter) 
            self.label_5.setPixmap(QPixmap(pixmap2))
            self.label_5.setAlignment(Qt.AlignCenter)

app = QtWidgets.QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()