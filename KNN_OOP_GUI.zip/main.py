import sys
from cls_Knn import *
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtWidgets import (
    QAction,
    QApplication,
    QCheckBox,
    QLabel,
    QMainWindow,
    QStatusBar,
    QToolBar,
)

from MainWindow import Ui_MainWindow

class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, *args, obj=None, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.setupUi(self)
        self.menuBar()
        self.setStyleSheet("background-color: White;")
        self.k = 3
        self.action100x100.triggered.connect(lambda: self.set_model_100())
        self.action200x200.triggered.connect(lambda: self.set_model_200())
        self.actionOpen_Image.triggered.connect(lambda: self.openFileNameDialog())
        pixmap = QPixmap('start.png')
        self.label_tIMG.setPixmap(QPixmap(pixmap))
        self.label_tIMG.setAlignment(Qt.AlignCenter)
        self.label_tIMG_2.setPixmap(QPixmap(pixmap))
        self.label_tIMG_2.setAlignment(Qt.AlignCenter)
        pixmap2 = QPixmap('start_2.png')
        self.label_3.setPixmap(QPixmap(pixmap2))
        self.label_3.setAlignment(Qt.AlignCenter)        
        self.label_4.setPixmap(QPixmap(pixmap2))
        self.label_4.setAlignment(Qt.AlignCenter) 
        self.label_5.setPixmap(QPixmap(pixmap2))
        self.label_5.setAlignment(Qt.AlignCenter)
        self.label.setText('Model: ')
        self.label_2.setText('Test File: ')
        self.radioButton.k = 5
        self.radioButton.toggled.connect(self.onClicked)
        self.radioButton_2.setChecked(True)
        self.radioButton_2.k = 3
        self.radioButton_2.toggled.connect(self.onClicked)
        self.pushButton.clicked.connect(lambda: self.run_knn())


    def run_knn(self):

        print(f'K-value: {self.k}')
        print(f'Model: {self.Model}')
        print(f'Test File: {self.test_file}')
        print(f'Width: {self.b}')
        print(f'Height: {self.h}')

        knn_model = Calculate_Knn(self.test_file, self.Model, self.b, self.h, self.k)
        knn_model.file_index
        knn_model.file_list
        self.knn_cs = list(set(knn_model.class_list))
        res_txt = ''
        for i in range(len(self.knn_cs)):
            res_txt = res_txt + f'{self.knn_cs[i]}: {knn_model.class_list.count(self.knn_cs[i])}\n'

        self.res_txt = res_txt
        print(self.res_txt)
        self.textBrowser.setText(self.res_txt)
        pixmap = QPixmap('grey_tmp_img.png')
        self.label_tIMG_2.setPixmap(QPixmap(pixmap))
        self.label_tIMG_2.resize(pixmap.width(),pixmap.height())
        self.label_tIMG_2.setAlignment(Qt.AlignCenter)

        n = 1
        for i in range(len(knn_model.file_index)):
            if n == 1:
                pixmap3 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            if n == 2:
                pixmap4 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            if n == 3:
                pixmap5 = QPixmap(knn_model.file_list[int(knn_model.file_index[i])])
            n +=1

        self.label_4.setPixmap(QPixmap(pixmap4))       
        self.label_5.setPixmap(QPixmap(pixmap5))
        self.label_3.setPixmap(QPixmap(pixmap3))

    def onClicked(self):
        radioButton = self.sender()
        if radioButton.isChecked():
            self.k = radioButton.k

    def set_model_100(self):
        self.label.setText('Model: 100x100')
        self.Model = '/Users/jeskils/knn/Model_Img_(100x100).npz'
        self.b = 100
        self.h = 100

    def set_model_200(self):
        self.label.setText('Model: 200x200')
        self.Model = '/Users/jeskils/knn/Model_Img_(200x200).npz'
        self.b = 200
        self.h = 200

    def openFileNameDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName, _ = QFileDialog.getOpenFileName(self,"QFileDialog.getOpenFileName()", "/Users/jeskils/knn/test","Img Files (*.jpg)", options=options)
        if fileName:
            print(fileName)
            self.test_file = fileName
            fN = fileName.split('/')
            self.label_2.setText(fN[5])
            img = Image.open(fileName)
            b = img.size[0]
            h = img.size[1]
            if b > 300 or h > 300:
                size = (int(b*0.5), int(h*0.5))
            else:
                size = (int(b), int(h))
            img = img.resize(size)
            img.save('tmp_img.png')
            pixmap = QPixmap('tmp_img.png')
            self.label_tIMG.setPixmap(QPixmap(pixmap))
            self.label_tIMG.resize(pixmap.width(),pixmap.height())
            self.label_tIMG.setAlignment(Qt.AlignCenter)

app = QtWidgets.QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()