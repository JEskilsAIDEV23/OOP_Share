import numpy as np
from PIL import Image

def np2img(model_file):

    with np.load('Model_Img_(50x50).npz') as data:
        bilder = data['bilder']
        file_list = data['file_list']
        model_id_list = data['model_id_list']

    pixels = np.reshape(bilder[0], [50,50])

    image = Image.fromarray(pixels, 'L')
    image = Image.fromarray(pixels.astype('uint8'), 'L')
    image.save('image.png')
