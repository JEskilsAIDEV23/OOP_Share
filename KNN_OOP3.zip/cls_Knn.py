import os
import numpy as np
from PIL import Image, ImageOps
import math

class Paths2files():
    def __init__(self) -> None:
        self.path2f = []
        self.cluster_n = []
        self.file_list = []

    def set_cluster_names(self, n = []):
        self.cluster_n = n

    def set_path2f(self, p2f = []):
        self.path2f = p2f

        for i in self.path2f:
            files = os.listdir(i)
            for j in files:
                if '.png' in j or '.jpeg' in j or '.jpg' in j:
                    if 'grey' not in j:
                        self.file_list.append(i+'/'+j)

class Files2model(Paths2files):
    def __init__(self) -> None:
        super().__init__()

        self.model_id_list = []
        self.model_file_list = []

    def model_file(self):

        model_id_list = []
        model_file_list = []

        for i in range(len(self.file_list)):
            for j in range(len(self.cluster_n)):
                if self.cluster_n[j] in self.file_list[i]:
                    model_id_list.append(self.cluster_n[j])
                    model_file_list.append(self.file_list[i])

        self.model_file_list = model_file_list
        self.model_id_list = model_id_list

        return self.model_id_list, self.model_file_list

class Knn:
    def __init__(self, b, h, k=3) -> None:
        self.k = k
        self.b = b
        self.h = h

class Load_model(Knn):
    def __init__(self, m_file, b, h, k=3) -> None:
        super().__init__(b, h, k)

        with np.load(m_file) as data:
            self.bilder = data['bilder']
            self.file_list = data['file_list']
            self.model_id_list = data['model_id_list']

class Calculate_Knn(Load_model):
    def __init__(self, t_file, m_file, b, h, k=3) -> None:
        super().__init__(m_file, b, h, k)

        # Open the image
        img = Image.open(t_file)
        # Convert the image to grayscale
        img = img.convert("L")
        # Target image size
        size = (b, h)
        # Scale the image
        img = img.resize(size)
        # save file
        img.save('grey_tmp_img.png')
        # make np array
        img = np.asarray(img)
        # make flat array, single vector
        self.test_bild = img.flatten('C')
        # save as np array
        np.savez('Test_Img', test_bild = self.test_bild)

        self.pred_list = []
        self.model_dict = {}

        for j in range(len(self.bilder)):

            self.model_dict[str(j)+' '+self.model_id_list[j]] = ''
            bild = self.bilder[j,:]
            dist_1 = 0

            for i in range(len(self.test_bild)):
                dist_1 += (int(self.test_bild[i]) - int(bild[i]))**2
            dist = math.sqrt(dist_1)
            self.pred_list.append(dist)
            self.model_dict[str(j)+' '+self.model_id_list[j]] = dist

        pred_l = self.pred_list.copy()
        pred_l.sort()
        xp = pred_l[0:k]
        self.class_list = []
        self.file_index = []

        for i in range(len(xp)):
            for key in self.model_dict.keys():
                if xp[i] == self.model_dict[key]:
                    key1 = key.split()[1]
                    keyf = key.split()[0]
                    self.class_list.append(key1)
                    self.file_index.append(keyf)

        print(self.class_list, self.file_index)


def scale_n_grey_fnp(model_file_list, b, h):

    model_sng_list = []

    for i in model_file_list:
        img = Image.open(i)
        # Convert the image to grayscale
        img = img.convert("L")
        # Target image size
        size = (b, h)
        # Scale the image
        scaled_img = img.resize(size)
        # Save the scaled image
        i = i.replace('.png', '')
        scaled_img.save(i+'_grey_scaled('+str(b)+'x'+str(h)+')'+'.png')
        model_sng_list.append(i+'_grey_scaled('+str(b)+'x'+str(h)+')'+'.png')

    return model_sng_list

def make_model_file(model_sng_list, model_id_list, model_name = 'Model_Img_'):

    file_list = model_sng_list
    n = len(file_list)
    img = Image.open(file_list[0])
    b = img.size[0]
    h = img.size[1]
    img = np.asarray(img)
    img = img.flatten('C')
    n_flat = len(img)
    bilder = np.zeros([n, n_flat])

    for i in range(n):
        img = Image.open(file_list[i])  
        img_array = np.asarray(img)
        bilder[i,:] = img_array.flatten('C')

    file_s = model_name +'('+str(b)+'x'+str(h)+')'
    np.savez(file_s, bilder=bilder, file_list = file_list, model_id_list = model_id_list)  
    return bilder

def x_img(test_img='tmp_img.png', cross_img='cross.png'):

    # Open the base and overlay images
    base_img = Image.open(test_img)
    b = base_img.size[0]
    h = base_img.size[1]
    overlay_img = Image.open(cross_img)

    # Resize the images to the same size
    overlay_img = overlay_img.resize((b, h))
    # Convert images to same mode
    overlay_img = overlay_img.convert('RGB')
    # Define the weight of each image
    alpha = 0.5
    # Blend the images together
    blended = Image.blend(base_img, overlay_img, alpha)
    # Save the blended image
    blended.save('Xtmp_img.png')


def np2img(model_file):

    with np.load('Model_Img_(50x50).npz') as data:
        bilder = data['bilder']
        file_list = data['file_list']
        model_id_list = data['model_id_list']
        pixels = np.reshape(bilder[0], [50,50])
        image = Image.fromarray(pixels, 'L')
        image = Image.fromarray(pixels.astype('uint8'), 'L')
        image.save('image.png')

