import sys
import os
from cls_Knn import *
from PIL import Image, ImageOps

import sys

from PyQt5.QtGui import QImage
from PyQt5.QtWidgets import *

