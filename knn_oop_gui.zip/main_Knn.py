import numpy as np
import math
from PIL import Image
from cls_Knn import *

#pf = Files2model()
#pf.set_path2f(['/Users/jeskils/knn/Dice/train/'])
#pf.set_cluster_names(['1','2','3','4','5','6'])
#model_id_list, model_file_list = pf.model_file()
#model_sng_list = scale_n_grey_fnp(model_file_list, 100 , 100)
#bilder = make_model_file(model_sng_list, model_id_list)

d = Calculate_Knn('/Users/jeskils/knn/Dice/3/3.png','/Users/jeskils/knn/Model_Img_(100x100).npz',100,100,3)



    

