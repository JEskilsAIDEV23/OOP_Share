import sys
from PyQt5 import QtWidgets, uic, QtGui, QtDesigner, QtCore, QtQuickWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QLabel
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt
from MainWindow import Ui_MainWindow
from cls_Knn import *

class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, *args, obj=None, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.setupUi(self)
        self.setStyleSheet("background-color: Green;")
        self.label.setStyleSheet("background-color: White;")
        self.label_2.setStyleSheet("background-color: White;")
        self.label_3.setStyleSheet("background-color: White;")
        self.label_4.setStyleSheet("background-color: White;")
        pixmap6 = QPixmap('Dice/6/6.png')
        self.label.setPixmap(QPixmap(pixmap6))
        self.label.resize(pixmap6.width(),pixmap6.height())
        self.label.setAlignment(Qt.AlignCenter)
        self.label_2.setPixmap(QPixmap(pixmap6))
        self.label_2.resize(pixmap6.width(),pixmap6.height())
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_3.setPixmap(QPixmap(pixmap6))
        self.label_3.resize(pixmap6.width(),pixmap6.height())
        self.label_3.setAlignment(Qt.AlignCenter)
        self.label_4.setPixmap(QPixmap(pixmap6))
        self.label_4.resize(pixmap6.width(),pixmap6.height())
        self.label_4.setAlignment(Qt.AlignCenter)

        test_file = '/Users/jeskils/knn/Dice/3/3n.png'
        pixmap4 = QPixmap(test_file)
        self.label_4.setPixmap(QPixmap(pixmap4))

        d = Calculate_Knn(test_file,'/Users/jeskils/knn/Model_Img_(100x100).npz',100,100,3)
  
        for i in range(len(d.file_index)):
            if i == 0:
                pixmap1 = QPixmap(d.file_list[int(d.file_index[i])])
            if i == 1:
                pixmap2 = QPixmap(d.file_list[int(d.file_index[i])])
            if i == 2:
                pixmap3 = QPixmap(d.file_list[int(d.file_index[i])])
  
        self.label.setPixmap(QPixmap(pixmap1))
        self.label_2.setPixmap(QPixmap(pixmap2))        
        self.label_3.setPixmap(QPixmap(pixmap3))

app = QtWidgets.QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()