import os
import numpy as np
import PIL
from PIL import Image

def list_file():

    file_list_1 = os.listdir('/Users/jeskils/knn/Dice/1')
    file_list_2 = os.listdir('/Users/jeskils/knn/Dice/2')
    file_list_3 = os.listdir('/Users/jeskils/knn/Dice/3')
    file_list_4 = os.listdir('/Users/jeskils/knn/Dice/4')
    file_list_5 = os.listdir('/Users/jeskils/knn/Dice/5')
    file_list_6 = os.listdir('/Users/jeskils/knn/Dice/6')
    file_list = []

    for i in file_list_1:
        file_list.append('/Users/jeskils/knn/Dice/1/'+i)
    for i in file_list_2:
        file_list.append('/Users/jeskils/knn/Dice/2/'+i)
    for i in file_list_3:
        file_list.append('/Users/jeskils/knn/Dice/3/'+i)
    for i in file_list_4:
        file_list.append('/Users/jeskils/knn/Dice/4/'+i)   
    for i in file_list_5:
        file_list.append('/Users/jeskils/knn/Dice/5/'+i)  
    for i in file_list_6:
        file_list.append('/Users/jeskils/knn/Dice/6/'+i)

    np.savez('file_list', file_list = file_list)

def conv2grey(file_list):

    for i in file_list:
        # Open the image
        img = Image.open(i)
        # Convert the image to grayscale
        img = img.convert("L")
        # Save the grayscale image
        img.save(i+'_grey.png')

def list_grey():

    file_list_1 = os.listdir('/Users/jeskils/knn/Dice/1')
    file_list_2 = os.listdir('/Users/jeskils/knn/Dice/2')
    file_list_3 = os.listdir('/Users/jeskils/knn/Dice/3')
    file_list_4 = os.listdir('/Users/jeskils/knn/Dice/4')
    file_list_5 = os.listdir('/Users/jeskils/knn/Dice/5')
    file_list_6 = os.listdir('/Users/jeskils/knn/Dice/6')
    file_list = []

    for i in file_list_1:
        file_list.append('/Users/jeskils/knn/Dice/1/'+i)
    for i in file_list_2:
        file_list.append('/Users/jeskils/knn/Dice/2/'+i)
    for i in file_list_3:
        file_list.append('/Users/jeskils/knn/Dice/3/'+i)
    for i in file_list_4:
        file_list.append('/Users/jeskils/knn/Dice/4/'+i)   
    for i in file_list_5:
        file_list.append('/Users/jeskils/knn/Dice/5/'+i)  
    for i in file_list_6:
        file_list.append('/Users/jeskils/knn/Dice/6/'+i)

    file_list_grey = []
    for i in file_list:
        if '_grey.png' in i:
            file_list_grey.append(i)

    np.savez('file_list_g', file_list = file_list_grey)


def list_scaled():

    file_list_1 = os.listdir('/Users/jeskils/knn/Dice/1')
    file_list_2 = os.listdir('/Users/jeskils/knn/Dice/2')
    file_list_3 = os.listdir('/Users/jeskils/knn/Dice/3')
    file_list_4 = os.listdir('/Users/jeskils/knn/Dice/4')
    file_list_5 = os.listdir('/Users/jeskils/knn/Dice/5')
    file_list_6 = os.listdir('/Users/jeskils/knn/Dice/6')
    file_list = []

    for i in file_list_1:
        file_list.append('/Users/jeskils/knn/Dice/1/'+i)
    for i in file_list_2:
        file_list.append('/Users/jeskils/knn/Dice/2/'+i)
    for i in file_list_3:
        file_list.append('/Users/jeskils/knn/Dice/3/'+i)
    for i in file_list_4:
        file_list.append('/Users/jeskils/knn/Dice/4/'+i)   
    for i in file_list_5:
        file_list.append('/Users/jeskils/knn/Dice/5/'+i)  
    for i in file_list_6:
        file_list.append('/Users/jeskils/knn/Dice/6/'+i)

    file_list_grey_s = []
    for i in file_list:
        if '_scaled.png' in i:
            file_list_grey_s.append(i)

    np.savez('file_list_s', file_list = file_list_grey_s)   


def scale_img(file):

    with np.load(file) as data:

        file_list = data['file_list']

    for i in file_list:
    # Read the input image
        img = Image.open(i)
    # Target image size
        size = (100, 100)
    # Scale the image
        scaled_img = img.resize(size)
    # Save the scaled image
        scaled_img.save(i+'_scaled.png')


def load_img(file_list_file, type = 'g_'):

    with np.load(file_list_file) as data:
        file_list = data['file_list']

    n = len(file_list)
    img = Image.open(file_list[0])   
    img = np.asarray(img)
    img = img.flatten('C')
    n_flat = len(img)
    bilder = np.zeros([n, n_flat])

    for i in range(n):
        img = Image.open(file_list[i])  
        img_array = np.asarray(img)
        bilder[i,:] = img_array.flatten('C')

    np.savez(type+'bilder_n_list', bilder=bilder, file_list = file_list)


#list_file()
#list_grey()
#list_scaled()
#scale_img('file_list.npz')
#load_img('file_list_g_s.npz')
#img, test_bild = test_img('/Users/jeskils/knn/Dice/1/1n.png')



