import numpy as np
import math
import os
from PIL import Image

def test_img(file):

    # Open the image
    img = Image.open(file)
    # Convert the image to grayscale
    img = img.convert("L")
    # Target image size
    size = (100, 100)
    # Scale the image
    img = img.resize(size)
    # make np array
    img = np.asarray(img)
    # make flat array, single vector
    test_bild = img.flatten('C')
    # save as np array
    np.savez('Test_Img', test_bild = test_bild)
    return img, test_bild


def load_data(file, class_names = ['1', '2', '3', '4', '5', '6']):

    with np.load(file) as data:
        bilder = data['bilder']
        file_list = data['file_list']

    class_id = []

    for i in file_list:
        for j in class_names:
            if j in i:
                class_id.append(j)

    return bilder, class_id


def knn(test_bild, bilder, class_id, k=3):

    pred_list = []
    model_dict = {}

    for j in range(len(bilder)):

        model_dict[str(j)+' '+class_id[j]] = ''
        bild = bilder[j,:]
        dist_1 = 0

        for i in range(len(test_bild)):
            dist_1 += (int(test_bild[i]) - int(bild[i]))**2
        dist = math.sqrt(dist_1)
        pred_list.append(dist)
        model_dict[str(j)+' '+class_id[j]] = dist

    pred_list.sort()
    xp = pred_list[0:k]
    class_list = []

    for i in range(len(xp)):
        for key in model_dict.keys():
            if xp[i] == model_dict[key]:
                key = key.split()[1]
                class_list.append(key)

    print(class_list)

img, test_bild = test_img('/Users/jeskils/knn/Dice/4/4n.png')
bilder, class_id = load_data('g_bilder_n_list.npz', class_names = ['1', '2', '3', '4', '5', '6'])
knn(test_bild, bilder, class_id, k=7)